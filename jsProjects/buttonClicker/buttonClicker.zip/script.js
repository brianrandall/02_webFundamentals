function logOut(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}

function likePopup(element) {
    alert("Ninja was liked");
}