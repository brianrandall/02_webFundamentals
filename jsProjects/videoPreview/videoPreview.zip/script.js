console.log("page loaded...");



function playVid(element) {
    element.play();
    console.log("moused");

}

function stopVid(element) {
    element.pause();
    console.log("unmoused");
}