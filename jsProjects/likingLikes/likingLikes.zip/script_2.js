var j = 9;
var neilLikesElement = document.querySelector('#neilLikes');
neilLikesElement.innerText = j;

function addLikesNeil () {
    var neilLikesElement = document.querySelector('#neilLikes');
    j += 1;
    neilLikesElement.innerText = j;
}

var k = 12;
var nicholeLikesElement = document.querySelector('#nicholeLikes');
nicholeLikesElement.innerText = k;

function addLikesNichole () {
    var neilLikesElement = document.querySelector('#nicholeLikes');
    k += 1;
    nicholeLikesElement.innerText = k;
}

var l = 9;
var jimLikesElement = document.querySelector('#jimLikes');
jimLikesElement.innerText = l;

function addLikesJim () {
    var jimLikesElement = document.querySelector('#jimLikes');
    l += 1;
    jimLikesElement.innerText = l;
}